export class User {
    public uuid: string = '';
    public firstName: string = '';
    public lastName: string = '';
    public cpf: string = '';
    public email: string = '';
    public mobileNumber: string = '';
    public address: string = '';
    public city: string = '';
    public state: string = '';
    public zipcode: string = '';
    public genderType: string = '';
    public birthdate: string = '';
    public stateAddress: string = '';
    public cityAddress: string = '';
    public districtAddress: string = '';
    public numberAddress: string = '';
    public password: string = '';
    public statusType: string = '';
    public educationFormation: string = '';
}