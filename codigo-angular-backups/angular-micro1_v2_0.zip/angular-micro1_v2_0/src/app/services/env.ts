const PROD_URL = 'http://api.urbanagros.com.br/';
const DEV_URL = 'http://localhost:3000/';


export const environment = {

    production: false,
  
    title: 'url',
  
    apiURL: PROD_URL
  
};