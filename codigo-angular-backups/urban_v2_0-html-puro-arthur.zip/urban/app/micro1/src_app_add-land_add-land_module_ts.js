"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_add-land_add-land_module_ts"],{

/***/ 9642:
/*!*****************************************************!*\
  !*** ./src/app/add-land/add-land-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddLandPageRoutingModule": () => (/* binding */ AddLandPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _add_land_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-land.page */ 8729);




const routes = [
    {
        path: '',
        component: _add_land_page__WEBPACK_IMPORTED_MODULE_0__.AddLandPage
    }
];
let AddLandPageRoutingModule = class AddLandPageRoutingModule {
};
AddLandPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddLandPageRoutingModule);



/***/ }),

/***/ 9473:
/*!*********************************************!*\
  !*** ./src/app/add-land/add-land.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddLandPageModule": () => (/* binding */ AddLandPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _add_land_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-land-routing.module */ 9642);
/* harmony import */ var _add_land_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-land.page */ 8729);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _services_land_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/land.service */ 2581);









let AddLandPageModule = class AddLandPageModule {
};
AddLandPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule,
            _add_land_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddLandPageRoutingModule
        ],
        providers: [_services_land_service__WEBPACK_IMPORTED_MODULE_2__.LandService],
        declarations: [_add_land_page__WEBPACK_IMPORTED_MODULE_1__.AddLandPage]
    })
], AddLandPageModule);



/***/ }),

/***/ 8729:
/*!*******************************************!*\
  !*** ./src/app/add-land/add-land.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddLandPage": () => (/* binding */ AddLandPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _add_land_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-land.page.html?ngResource */ 7126);
/* harmony import */ var _add_land_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-land.page.scss?ngResource */ 1592);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 6439);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 8759);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _models_land__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/land */ 5158);
/* harmony import */ var _services_land_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/land.service */ 2581);










let AddLandPage = class AddLandPage {
    constructor(service, routeAct, router, formBuilder) {
        this.service = service;
        this.routeAct = routeAct;
        this.router = router;
        this.formBuilder = formBuilder;
        this.land = new _models_land__WEBPACK_IMPORTED_MODULE_2__.Land();
        this.landForm = this.formBuilder.group({
            'name': [this.land.name, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'address': [this.land.address, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'city': [this.land.cityAddress, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'state': [this.land.state, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'zipcode': [this.land.zipcode, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
        });
        this.isLoadingResults = false;
        this.id = routeAct.snapshot.params['id'];
        this.title = 'Add';
    }
    ngOnInit() {
        if (this.id) {
            this.title = 'Edit';
            // This is not the ideal way to pass information to another component.
            // There are other forms such as Inputs, Redux and Services, but due to lack of time I decided to use this technique.
            if (localStorage.getItem('land')) {
                this.land = JSON.parse(localStorage.getItem('land') || '{}');
            }
            //this.landForm = 
        }
        else {
            this.landForm = this.formBuilder.group({
                'name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
                'address': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
                'city': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
                'state': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
                'zipcode': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
            });
        }
    }
    submitUserForm(form) {
        this.isLoadingResults = true;
        this.land = this.landForm.value;
        if (this.id) {
            let data = {
                name: this.land.name,
                address: this.land.address,
                number: this.land.numberAddress,
                city: this.land.cityAddress,
                user_id: 1
            };
            this.land.id = this.id;
            this.service.editLand(data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)((retorno) => console.log("User Add")), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.catchError)(() => {
                //aqui tem exebir um tost ou uma mensagem para usuários com erro
                //vou colocar uma alert depois olhamos como podemos retornar o erro
                alert('Ocorreu um erro');
                return rxjs__WEBPACK_IMPORTED_MODULE_7__.EMPTY;
            })).subscribe({
                next: (response) => {
                    console.log('entrou no response');
                    console.log(response);
                    this.router.navigate(['animals']);
                },
                error: (erro) => {
                    console.log('entrou no erro');
                    alert("Usuário ou Senha inválido(s)!");
                    console.log(erro);
                }
            });
        }
        else {
            /*
      export class Land {
        public id: number = 0;
        public name: string = '';
        public address: string = '';
        public cityAddress: string = '';
        public districtAddress: string = '';
        public state: string = '';
        public numberAddress: string = '';
        public zipcode: string = '';
        public landArea: string = '';
    }*/
            let data = {
                name: this.landForm.controls['name'].value,
                address: this.landForm.controls['address'].value,
                cityAddress: this.landForm.controls['city'].value,
                districAddress: 'Morro Alto',
                state: this.landForm.controls['state'].value,
                numberAddress: 122,
                zipcode: '121321',
                landArea: 124.251,
            };
            this.service.addLand(data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)((retorno) => console.log("User Add")), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.catchError)(() => {
                //aqui tem exebir um tost ou uma mensagem para usuários com erro
                //vou colocar uma alert depois olhamos como podemos retornar o erro
                alert('Ocorreu um erro');
                return rxjs__WEBPACK_IMPORTED_MODULE_7__.EMPTY;
            })).subscribe({
                next: (response) => {
                    console.log('entrou no response');
                    console.log(response);
                    this.router.navigate(['animals']);
                },
                error: (erro) => {
                    console.log('entrou no erro');
                    alert("Usuário ou Senha inválido(s)!");
                    console.log(erro);
                }
            });
            // nextHandler
        }
    }
};
AddLandPage.ctorParameters = () => [
    { type: _services_land_service__WEBPACK_IMPORTED_MODULE_3__.LandService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.UntypedFormBuilder }
];
AddLandPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-add-land',
        template: _add_land_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_add_land_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AddLandPage);



/***/ }),

/***/ 5158:
/*!********************************!*\
  !*** ./src/app/models/land.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Land": () => (/* binding */ Land)
/* harmony export */ });
class Land {
    constructor() {
        this.id = 0;
        this.name = '';
        this.address = '';
        this.cityAddress = '';
        this.districtAddress = '';
        this.state = '';
        this.numberAddress = '';
        this.zipcode = '';
        this.landArea = '';
    }
}


/***/ }),

/***/ 2581:
/*!******************************************!*\
  !*** ./src/app/services/land.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandService": () => (/* binding */ LandService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 4139);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 8759);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./env */ 8594);






const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
};
let LandService = class LandService {
    constructor(http) {
        this.http = http;
        this.httpOptionsToken = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
        this.BASE_URL = _env__WEBPACK_IMPORTED_MODULE_0__.environment.apiURL;
        if (sessionStorage.getItem('token'))
            this.httpOptionsToken = {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + sessionStorage.getItem('token')
                })
            };
    }
    /**  POST  user api  ADD Land Function  */
    addLand(land) {
        console.log(land);
        var url = this.BASE_URL + 'api/v1/land';
        return this.http.post(url, land, this.httpOptionsToken);
    }
    /**  PUT land api EDIT Land Function  */
    editLand(land) {
        var url = this.BASE_URL + 'api/v1/land' + land.id;
        ;
        return this.http.put(url, land, httpOptions);
    }
    /**  GET land api Gell All Custmoer Function  */
    getLands() {
        var url = this.BASE_URL + 'api/v1/land';
        return this.http.get(url)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(todos => console.log('Get Land From API')), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError('getLands', [])));
    }
    /** DELETE: delete land Function*/
    deleteLand(land) {
        const id = typeof land === 'number' ? land : land.id;
        var url = this.BASE_URL + 'api/v1/land' + id;
        return this.http.delete(url, httpOptions)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.tap)(_ => console.log(`deleted land id=${id}`)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.handleError('deleteLand')));
    }
    handleError(operation = 'operation', result) {
        return (error) => {
            console.error(error); // log to console instead
            console.log(`${operation} failed: ${error.message}`);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(result);
        };
    }
};
LandService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
LandService = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], LandService);



/***/ }),

/***/ 1592:
/*!********************************************************!*\
  !*** ./src/app/add-land/add-land.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ".example-card {\n  width: 500px;\n}\n\n/* Structure */\n\n.example-container {\n  position: relative;\n  padding: 3px;\n  background: #f2f2f2;\n}\n\n.example-form {\n  min-width: 150px;\n  max-width: 500px;\n  width: 60%;\n}\n\n.example-full-width {\n  width: 100%;\n}\n\n.button-row {\n  margin: 10px 0;\n}\n\n.mat-flat-button {\n  margin: 5px;\n}\n\n.center {\n  width: 75%;\n  margin: 2px auto;\n}\n\n.main-div {\n  height: 100vh;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC1sYW5kLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUFDSjs7QUFDRSxjQUFBOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFFSjs7QUFBRTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBR0o7O0FBREU7RUFDRSxXQUFBO0FBSUo7O0FBREU7RUFDRSxjQUFBO0FBSUo7O0FBRkU7RUFDRSxXQUFBO0FBS0o7O0FBSEU7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFNSjs7QUFKRTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQU9KIiwiZmlsZSI6ImFkZC1sYW5kLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leGFtcGxlLWNhcmR7XG4gICAgd2lkdGg6IDUwMHB4O1xuICB9XG4gIC8qIFN0cnVjdHVyZSAqL1xuICAuZXhhbXBsZS1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBwYWRkaW5nOiAzcHg7XG4gICAgYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgfVxuICAuZXhhbXBsZS1mb3JtIHtcbiAgICBtaW4td2lkdGg6IDE1MHB4O1xuICAgIG1heC13aWR0aDogNTAwcHg7XG4gICAgd2lkdGg6IDYwJTtcbiAgfVxuICAuZXhhbXBsZS1mdWxsLXdpZHRoIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuXG4gIC5idXR0b24tcm93IHtcbiAgICBtYXJnaW46IDEwcHggMDtcbiAgfVxuICAubWF0LWZsYXQtYnV0dG9uIHtcbiAgICBtYXJnaW46IDVweDtcbiAgfVxuICAuY2VudGVye1xuICAgIHdpZHRoOiA3NSU7XG4gICAgbWFyZ2luOiAycHggYXV0bztcbiAgfVxuICAubWFpbi1kaXZ7XG4gICAgaGVpZ2h0OiAxMDB2aDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cbiAgIl19 */";

/***/ }),

/***/ 7126:
/*!********************************************************!*\
  !*** ./src/app/add-land/add-land.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "\n\n<ion-content>\n  <div class=\"example-container \">\n    <div class=\"example-loading-shade\" *ngIf=\"isLoadingResults\">\n        <span *ngIf=\"isLoadingResults\">Loading</span>\n    </div>\n    <div class=\"main-div\">\n        <div class=\"example-card\">\n            <div>\n                <div>Adicionar terreno</div>\n            </div>\n            <form [formGroup]=\"landForm\" (ngSubmit)=\"submitUserForm(landForm.value)\">\n\n                <div class=\"mb-3 mt-3\">\n                    <label for=\"text\" class=\"form-label\">Descrição:</label>\n                    <input type=\"text\" class=\"form-control\" id=\"email\" placeholder=\"Name\" formControlName=\"name\">\n                    <div>\n                        <span *ngIf=\"!landForm.get('name')?.valid && landForm.get('name')?.touched\">Please\n                            enter Name</span>\n                    </div>\n                </div>\n \n                <div class=\"mb-3 mt-3\">\n                    <label for=\"text\" class=\"form-label\">Endereço:</label>\n                    <input  placeholder=\"Address\"  class=\"form-control\" formControlName=\"address\" >\n                    <div>\n                        <span *ngIf=\"!landForm.get('address')?.valid && landForm.get('address')?.touched\">Please\n                            Endereço</span>\n                    </div>\n                </div>\n                <div class=\"mb-3 mt-3\">\n                    <label for=\"text\" class=\"form-label\">Cidade:</label>\n                    <input placeholder=\"City\"  class=\"form-control\"  formControlName=\"city\" >\n                    <div>\n                        <span *ngIf=\"!landForm.get('city')?.valid && landForm.get('city')?.touched\">Please\n                            enter City</span>\n                    </div>\n                </div>\n                <div class=\"mb-3 mt-3\">\n                    <label for=\"text\" class=\"form-label\">Estado:</label>\n                    <input  placeholder=\"Estate\"  class=\"form-control\"  formControlName=\"state\" >\n                    <div>\n                        <span *ngIf=\"!landForm.get('state')?.valid && landForm.get('state')?.touched\">Please\n                            enter Estate</span>\n                    </div>\n                </div>\n\n                <div class=\"mb-3 mt-3\">\n                    <label for=\"text\" class=\"form-label\">CEP:</label>\n                    <input placeholder=\"Zip\" class=\"form-control\" formControlName=\"zipcode\" >\n                    <div>\n                        <span *ngIf=\"!landForm.get('zipcode')?.valid && landForm.get('zipcode')?.touched\">Please\n                            CEP</span>\n                    </div>\n                </div>\n                <div class=\"button-row\">\n                    <button type=\"submit\" [disabled]=\"!landForm.valid\" class=\"btn btn-primary\">\n                        Cadastrar\n                    </button>\n                </div>\n            </form>\n        </div>\n    </div>\n</div>\n\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_add-land_add-land_module_ts.js.map