"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_register_register_module_ts"],{

/***/ 5783:
/*!********************************!*\
  !*** ./src/app/models/user.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "User": () => (/* binding */ User)
/* harmony export */ });
class User {
    constructor() {
        this.uuid = '';
        this.firstName = '';
        this.lastName = '';
        this.cpf = '';
        this.email = '';
        this.mobileNumber = '';
        this.address = '';
        this.city = '';
        this.state = '';
        this.zipcode = '';
        this.genderType = '';
        this.birthdate = '';
        this.stateAddress = '';
        this.cityAddress = '';
        this.districtAddress = '';
        this.numberAddress = '';
        this.password = '';
        this.statusType = '';
        this.educationFormation = '';
    }
}


/***/ }),

/***/ 3963:
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 8135);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 8723:
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 3963);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 8135);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/user.service */ 3071);









let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule
        ],
        providers: [_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 8135:
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page.html?ngResource */ 4754);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 6219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 6439);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 8759);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/user */ 5783);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/user.service */ 3071);










let RegisterPage = class RegisterPage {
    constructor(service, routeAct, router, routeActivate, formBuilder) {
        this.service = service;
        this.routeAct = routeAct;
        this.router = router;
        this.routeActivate = routeActivate;
        this.formBuilder = formBuilder;
        this.user = new _models_user__WEBPACK_IMPORTED_MODULE_2__.User();
        this.typeOfUser = '';
        this.userForm = this.formBuilder.group({
            'firstName': [this.user.firstName, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'lastName': [this.user.lastName, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'email': [this.user.email, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'mobileNumber': [this.user.mobileNumber, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'cpf': [this.user.address, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            'escolaridade': [this.user.address, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
        });
        this.isLoadingResults = false;
        this.id = routeAct.snapshot.params['id'];
        this.title = 'Add';
    }
    ngOnInit() {
        this.routeActivate.params.forEach((params) => {
            if (params['type'] !== undefined) {
                this.identificador = +params['type'];
                console.log(this.identificador);
            }
        });
        console.log(this.identificador);
        if (this.identificador === 1) {
            this.title = 'Edit';
            // This is not the ideal way to pass information to another component.
            // There are other forms such as Inputs, Redux and Services, but due to lack of time I decided to use this technique.
            if (sessionStorage.getItem('userInfo')) {
                console.log('edit');
                let userInfo = JSON.parse(sessionStorage.getItem('userInfo') || '{}');
                console.log(userInfo);
                /* 'mobileNumber': [this.user.mobileNumber, Validators.required],
            'cpf': [this.user.address, Validators.required],
            'escolaridade': [this.user.address, Validators.required] */
                this.userForm.setValue({
                    firstName: userInfo.name,
                    lastName: userInfo.lastName,
                    email: userInfo.email,
                    cpf: '3432432',
                    mobileNumber: '323232',
                    escolaridade: 'Superior Completo'
                });
            }
            else {
                console.log('register');
            }
            //this.userForm = 
        }
    }
    submitUserForm(form) {
        console.log('entrou 01');
        this.isLoadingResults = true;
        this.user = this.userForm.value;
        console.log(this.user);
        //let birthdate = this.user.birthdate.split("/");
        console.log('entrou 02');
        //console.log(birthdate)
        console.log('entrou 03');
        //this.user.birthdate = birthdate[2]+'/'+birthdate[1]+'/'+birthdate[0];
        console.log('entrou 04');
        console.log(this.user);
        /*
        {
          "email": "gabrielbdec2",
          "cpf": "048.356.251-37",
          "name": "Gabriel",
          "lastName": "Bernardes de Carvalho",
          "genderType": "MALE",
          "birthdate": "1996/08/30",
          "zipcode": "88906660",
          "mobileNumber": "+55(64)98142-2014",
          "stateAddress": "SC",
          "cityAddress": "Araranguá",
          "districtAddress": "Coloninha",
          "address": "Rua Joana Pereira Nazário",
          "numberAddress": "289",
          "password": "1234abcd",
          "educationFormation": "SUPERIOR_COMPLETE",
          "physicalPersonLicenseItems": [
              {
                "physicalPersonLicenseType": "ulala"
              },
              {
                  "physicalPersonLicenseType": "INVESTOR"
              }
          ]
        }
        */
        let data = {
            name: this.userForm.controls['firstName'].value,
            lastName: this.userForm.controls['lastName'].value,
            email: this.userForm.controls['email'].value,
            mobileNumber: this.userForm.controls['mobileNumber'].value,
            genderType: "MALE",
            birthdate: "1996/08/30",
            cpf: this.user.cpf,
            address: 'N-A',
            stateAddress: 'SC',
            zipcode: "88906660",
            numberAddress: "00000",
            districtAddress: "Santa Lucia",
            password: "1234abcd",
            cityAddress: 'Belo Horizonte',
            statusType: "CREATED",
            educationFormation: "SUPERIOR_COMPLETE",
            physicalPersonLicenseItems: [
                {
                    physicalPersonLicenseType: "INVESTOR"
                }
            ]
        };
        console.log(data);
        this.service.addUser(data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)((retorno) => console.log("User Add")), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.catchError)(() => {
            //aqui tem exebir um tost ou uma mensagem para usuários com erro
            //vou colocar uma alert depois olhamos como podemos retornar o erro
            alert('Ocorreu um erro');
            return rxjs__WEBPACK_IMPORTED_MODULE_7__.EMPTY;
        })).subscribe({
            next: (response) => {
                console.log('entrou no response');
                console.log(response);
                //this.router.navigate(['animals'])
                window.location.href = 'http://localhost/urban/page7.html';
            },
            error: (erro) => {
                console.log('entrou no erro');
                alert("Usuário ou Senha inválido(s)!");
                console.log(erro);
            }
        });
        // nextHandler
    }
};
RegisterPage.ctorParameters = () => [
    { type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.UntypedFormBuilder }
];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-register',
        template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 6219:
/*!********************************************************!*\
  !*** ./src/app/register/register.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "body {\n  color: #000;\n  overflow-x: hidden;\n  height: 100%;\n  background-image: url(\"https://i.imgur.com/GMmCQHC.png\");\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.card {\n  padding: 30px 40px;\n  margin-top: 60px;\n  margin-bottom: 60px;\n  border: none !important;\n  box-shadow: 0 6px 12px 0 rgba(0, 0, 0, 0.2);\n}\n\n.blue-text {\n  color: #00BCD4;\n}\n\n.form-control-label {\n  margin-bottom: 0;\n}\n\ninput, textarea, button {\n  padding: 8px 15px;\n  border-radius: 5px !important;\n  margin: 5px 0px;\n  box-sizing: border-box;\n  border: 1px solid #ccc;\n  font-size: 18px !important;\n  font-weight: 300;\n}\n\ninput:focus, textarea:focus {\n  box-shadow: none !important;\n  border: 1px solid #00BCD4;\n  outline-width: 0;\n  font-weight: 400;\n}\n\n.btn-block {\n  text-transform: uppercase;\n  font-size: 15px !important;\n  font-weight: 400;\n  height: 43px;\n  cursor: pointer;\n}\n\n.btn-block:hover {\n  color: #fff !important;\n}\n\nbutton:focus {\n  box-shadow: none !important;\n  outline-width: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFLLFdBQUE7RUFBWSxrQkFBQTtFQUFtQixZQUFBO0VBQWEsd0RBQUE7RUFBeUQsNEJBQUE7RUFBNkIsMEJBQUE7QUFPdkk7O0FBUGtLO0VBQU0sa0JBQUE7RUFBbUIsZ0JBQUE7RUFBaUIsbUJBQUE7RUFBb0IsdUJBQUE7RUFBd0IsMkNBQUE7QUFleFA7O0FBZmlTO0VBQVcsY0FBQTtBQW1CNVM7O0FBbkIyVDtFQUFvQixnQkFBQTtBQXVCL1U7O0FBdkJnVztFQUF3QixpQkFBQTtFQUFrQiw2QkFBQTtFQUE4QixlQUFBO0VBQWdCLHNCQUFBO0VBQXVCLHNCQUFBO0VBQXVCLDBCQUFBO0VBQTJCLGdCQUFBO0FBaUNqZ0I7O0FBakNraEI7RUFBaUcsMkJBQUE7RUFBNEIseUJBQUE7RUFBMEIsZ0JBQUE7RUFBaUIsZ0JBQUE7QUEwQzFyQjs7QUExQzJzQjtFQUFXLHlCQUFBO0VBQTBCLDBCQUFBO0VBQTJCLGdCQUFBO0VBQWlCLFlBQUE7RUFBYSxlQUFBO0FBa0R6eUI7O0FBbER5ekI7RUFBaUIsc0JBQUE7QUFzRDEwQjs7QUF0RGkyQjtFQUFrRiwyQkFBQTtFQUE0QixnQkFBQTtBQTZELzhCIiwiZmlsZSI6InJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJvZHl7Y29sb3I6ICMwMDA7b3ZlcmZsb3cteDogaGlkZGVuO2hlaWdodDogMTAwJTtiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJodHRwczovL2kuaW1ndXIuY29tL0dNbUNRSEMucG5nXCIpO2JhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7YmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCV9LmNhcmR7cGFkZGluZzogMzBweCA0MHB4O21hcmdpbi10b3A6IDYwcHg7bWFyZ2luLWJvdHRvbTogNjBweDtib3JkZXI6IG5vbmUgIWltcG9ydGFudDtib3gtc2hhZG93OiAwIDZweCAxMnB4IDAgcmdiYSgwLDAsMCwwLjIpfS5ibHVlLXRleHR7Y29sb3I6ICMwMEJDRDR9LmZvcm0tY29udHJvbC1sYWJlbHttYXJnaW4tYm90dG9tOiAwfWlucHV0LCB0ZXh0YXJlYSwgYnV0dG9ue3BhZGRpbmc6IDhweCAxNXB4O2JvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50O21hcmdpbjogNXB4IDBweDtib3gtc2l6aW5nOiBib3JkZXItYm94O2JvcmRlcjogMXB4IHNvbGlkICNjY2M7Zm9udC1zaXplOiAxOHB4ICFpbXBvcnRhbnQ7Zm9udC13ZWlnaHQ6IDMwMH1pbnB1dDpmb2N1cywgdGV4dGFyZWE6Zm9jdXN7LW1vei1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7LXdlYmtpdC1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7Ym94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O2JvcmRlcjogMXB4IHNvbGlkICMwMEJDRDQ7b3V0bGluZS13aWR0aDogMDtmb250LXdlaWdodDogNDAwfS5idG4tYmxvY2t7dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtmb250LXdlaWdodDogNDAwO2hlaWdodDogNDNweDtjdXJzb3I6IHBvaW50ZXJ9LmJ0bi1ibG9jazpob3Zlcntjb2xvcjogI2ZmZiAhaW1wb3J0YW50fWJ1dHRvbjpmb2N1c3stbW96LWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDstd2Via2l0LWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7b3V0bGluZS13aWR0aDogMH0iXX0= */";

/***/ }),

/***/ 4754:
/*!********************************************************!*\
  !*** ./src/app/register/register.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "\n\n<ion-content>\n  <div class=\"container-fluid px-1 py-5 mx-auto\">\n    <div class=\"row d-flex justify-content-center\">\n        <div class=\"col-xl-7 col-lg-8 col-md-9 col-11 text-center\">\n            <div class=\"card\">\n                <form [formGroup]=\"userForm\" class=\"form-card\" (ngSubmit)=\"submitUserForm(userForm.value)\">\n                    <div class=\"row justify-content-between text-left\">\n                        <div class=\"form-group col-sm-6 flex-column d-flex\"> \n                            <label class=\"form-control-label px-3\">Nome<span class=\"text-danger\"> *</span>\n                            </label> \n                            <input type=\"text\" id=\"fname\" name=\"firstName\" placeholder=\"Enter your first name\"  formControlName=\"firstName\" > \n                        </div>\n                        <div class=\"form-group col-sm-6 flex-column d-flex\"> \n                            <label class=\"form-control-label px-3\">Sobrenome<span class=\"text-danger\"> *</span>\n                            </label>\n                             <input type=\"text\" id=\"lname\" name=\"lastName\" placeholder=\"Enter your last name\" formControlName=\"lastName\" >\n                            </div>\n                    </div>\n                    <div class=\"row justify-content-between text-left\">\n                        <div class=\"form-group col-sm-6 flex-column d-flex\"> <label class=\"form-control-label px-3\">Email<span class=\"text-danger\"> *</span></label> \n                          <input type=\"text\" id=\"email\" name=\"email\" placeholder=\"\" formControlName=\"mobileNumber\" onblur=\"validate(3)\"> </div>\n                        <div class=\"form-group col-sm-6 flex-column d-flex\"> \n                            <label class=\"form-control-label px-3\">Telefone<span class=\"text-danger\"> *</span>\n                            </label> \n                            <input type=\"text\" id=\"mob\" name=\"mob\" placeholder=\"\" onblur=\"validate(4)\"> \n                        </div>\n                    </div>\n                    <div class=\"row justify-content-between text-left\">\n                        <div class=\"form-group col-sm-6 flex-column d-flex\"> \n                            <label class=\"form-control-label px-3\">CPF<span class=\"text-danger\"> *</span>\n                            </label> \n                          <input type=\"text\" id=\"email\" name=\"cpf\" placeholder=\"\"  formControlName=\"cpf\" > \n                        </div>\n                        <div class=\"form-group col-sm-6 flex-column d-flex\">\n                            <select class=\"form-select\" aria-label=\"Default select example\">\n                                <option selected>Escolaridade</option>\n                                <option value=\"1\">Superior Completo</option>\n                                <option value=\"2\">Sem escolaridade</option>\n                                <option value=\"3\">Ensino médio</option>\n                              </select>\n                        </div>                        \n                    </div>\n                    <div class=\"row justify-content-end\">\n                        <div class=\"form-group col-sm-6\"> \n                          <button type=\"submit\" class=\"btn-block btn-primary\">Cadastre-se</button> \n                        </div>\n                    </div>\n                </form>\n            </div>\n        </div>\n    </div>\n</div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_register_register_module_ts.js.map